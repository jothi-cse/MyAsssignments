package week1.day2;

public class LibraryManagement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Library lm = new Library();
		Library lm1 = new Library();
		System.out.println(lm.addBook("Success"));
		lm1.issueBook();
		
	}

}
