package week1.day2;

public class CheckNumberIsPositive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int version = 10;
		if (version >= 0) {
			System.out.println("Number is positive");
		} else {
			System.out.println("Number is negative");
		}
	}

}
